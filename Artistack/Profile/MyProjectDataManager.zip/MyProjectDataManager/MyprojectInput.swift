//
//  MyprojectInput.swift
//  Artistack
//
//  Created by 임영준 on 2022/08/18.
//

//struct MyprojectInput : Encodable {
//    
//    var page : Int
//    var size : Int
//    var sort : String
//}
