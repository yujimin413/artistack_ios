//
//  MyprojectDataManager.swift
//  Artistack
//
//  Created by 임영준 on 2022/08/18.
//

import Alamofire

class MyprojectDataManager {
    func getMyProject() {
        
        let header : HTTPHeaders = [
           "Content-Type" : "application/json;charset=UTF-8",
           "Authorization": "Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiI1MTMiLCJhcnRpc3RhY2tJZCI6Imxlb3Rlc3QzIiwibmlja25hbWUiOiJsZW9sZW8iLCJwcm92aWRlclR5cGUiOiJURVNUIiwicm9sZSI6IlVTRVIiLCJhdXRoIjoiVVNFUiIsImV4cCI6MTY2MDgzNjM4OX0.p7seEircAFOyoFthYq3__b9Vzi5HAuPj9AJjp9v-Tv-Va_PRCEHGx8NbdgIamtNpEgCwhkpBSTC4ge_TtBZEwg"]
        

        
        AF.request("https://dev.artistack.shop/projects/me?page=0&size=30&sort=id,desc", headers: header).validate().responseDecodable(of: MyprojectDataModel.self) { response in
            switch response.result {
                case .success(let result):
                    print("포스팅 성공")
                    debugPrint(response)
                case .failure(let error):
                    print("포스팅 실패")
                    print(error)
                debugPrint(response)
                }
        
        
        
        
//        AF.request("https://dev.artistack.shop/projects/me", method: .get, encoder: JSONParameterEncoder.default, headers: header).validate().responseDecodable(of: MyprojectDataModel.self) { response in
//            switch response.result {
//                case .success(let result):
//                    print("포스팅 성공")
//                    debugPrint(response)
//                case .failure(let error):
//                    print(error)
//                debugPrint(response)
//                }
        }
    }
}
